<?php
$con = mysqli_connect("localhost","root","","dbms_hotel") or die(mysql_error());

?>
